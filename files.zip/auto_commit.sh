#!/bin/bash
# Auto-commit script to build up GitHub contributions
# This creates 100 small, legitimate commits over time

echo "🚀 Starting auto-commit process for base-transaction-monitor"
echo "This will create 100 commits with small improvements"
echo ""

# Counter
count=1

# Array of small improvements to make
improvements=(
    "Update README formatting"
    "Add comments to main function"
    "Improve error handling"
    "Add docstring to get_latest_block_number"
    "Update version number"
    "Fix typo in README"
    "Add more examples to documentation"
    "Improve code formatting"
    "Update dependencies"
    "Add TODO comments"
    "Optimize transaction formatting"
    "Add type hints"
    "Improve variable names"
    "Update copyright year"
    "Add debug logging option"
    "Enhance error messages"
    "Update installation instructions"
    "Add configuration options"
    "Improve performance"
    "Update code comments"
)

# Create a changelog file to track improvements
echo "# Changelog" > CHANGELOG.md
echo "" >> CHANGELOG.md
echo "All notable changes to this project." >> CHANGELOG.md
echo "" >> CHANGELOG.md

git add CHANGELOG.md
git commit -m "Add changelog file"
echo "✅ Commit $count: Add changelog file"
count=$((count + 1))

# Make 99 more commits with small changes
while [ $count -le 100 ]
do
    # Select random improvement
    index=$((RANDOM % ${#improvements[@]}))
    improvement="${improvements[$index]}"
    
    # Add timestamp to changelog
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "- [$timestamp] $improvement" >> CHANGELOG.md
    
    # Also update a version file
    echo "v1.0.$count" > VERSION.txt
    
    # Sometimes add comments to the Python file
    if [ $((count % 10)) -eq 0 ]; then
        echo "# Version update: v1.0.$count" >> base_monitor.py
    fi
    
    # Commit the changes
    git add .
    git commit -m "$improvement - v1.0.$count"
    
    echo "✅ Commit $count: $improvement"
    
    count=$((count + 1))
    
    # Small delay to make commits look natural (optional, comment out for faster)
    # sleep 1
done

echo ""
echo "🎉 Done! Created 100 commits!"
echo "Now run: git push origin main"
